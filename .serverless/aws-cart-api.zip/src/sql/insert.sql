insert into carts (user_id, created_at, updated_at, status) values ('f9e909bf-cc04-4f6f-aa60-70ff04762c9a', '4/16/2023', '4/16/2023', 'OPEN');
insert into carts (user_id, created_at, updated_at, status) values ('f9e909bf-cc04-4f6f-aa60-70ff04762c9a', '1/12/2021', '3/20/2021', 'ORDERED');
insert into carts (user_id, created_at, updated_at, status) values ('ef5d7009-066d-464a-868f-6ec341bb9eb6', '2/15/2023', '3/14/2023', 'OPEN');
insert into carts (user_id, created_at, updated_at, status) values ('f68b63a9-ad38-4b0f-bc7d-b65c2e45a526', '5/10/2022', '10/10/2022', 'OPEN');
insert into carts (user_id, created_at, updated_at, status) values ('c28f6fbe-b6f3-48b6-bf1c-08b626b47215', '12/12/2022', '12/25/2022', 'ORDERED');

insert into cart_items (cart_id, product_id, count) values ('8c462dff-a350-4def-a766-74ec9d079429', '97bb7223-ca0e-409f-b599-ae998ac78bbb', 2);
insert into cart_items (cart_id, product_id, count) values ('8c462dff-a350-4def-a766-74ec9d079429', 'd40b66e7-f773-4f26-a729-89d17c6c17fb', 3);
insert into cart_items (cart_id, product_id, count) values ('17877c77-5ac5-4b96-b875-2b43dc2f8e63', 'd40b66e7-f773-4f26-a729-89d17c6c17fb', 5);
insert into cart_items (cart_id, product_id, count) values ('7ece3595-b601-4308-9a63-1ab0a5a07b2f', 'c5fdbee9-2ca1-4a7b-99ac-1ce2347af22a', 1);
insert into cart_items (cart_id, product_id, count) values ('30f105b2-4188-4acf-9446-6236337a217e', 'c5d9b59b-6e12-49e9-82d6-d1e7e10fee63', 13);
insert into cart_items (cart_id, product_id, count) values ('3e8385ed-0222-4dd5-b682-7fda3d95b892', 'c5d9b59b-6e12-49e9-82d6-d1e7e10fee63', 7);